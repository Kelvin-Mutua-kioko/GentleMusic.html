from flask import Flask, jsonify, request, send_from_directory, render_template
from werkzeug.utils import secure_filename
from pathlib import Path
import requests

BASE = Path(__file__).resolve().parent
MUSIC_DIR = BASE / 'music'
LYRICS_DIR = BASE / 'lyrics'
ALLOWED = {'.mp3','.wav','.ogg','.m4a','.aac','.flac'}
MUSIC_DIR.mkdir(exist_ok=True); LYRICS_DIR.mkdir(exist_ok=True)
app = Flask(__name__, template_folder='templates', static_folder='static')
app.config['MAX_CONTENT_LENGTH'] = 250 * 1024 * 1024

@app.get('/')
def home(): return render_template('index.html')

@app.get('/api/search')
def search():
    term=request.args.get('term','').strip()
    if not term: return jsonify(results=[],count=0)
    try:
        r=requests.get('https://itunes.apple.com/search',params={'term':term,'media':'music','entity':'song','limit':40},timeout=15)
        r.raise_for_status(); data=r.json(); out=[]
        for x in data.get('results',[]):
            out.append({'id':x.get('trackId'),'title':x.get('trackName') or 'Unknown Song','artist':x.get('artistName') or 'Unknown Artist','album':x.get('collectionName') or '','artwork':x.get('artworkUrl100') or '','previewUrl':x.get('previewUrl') or '','storeUrl':x.get('trackViewUrl') or '','source':'Apple Music preview','local':False})
        return jsonify(results=out,count=len(out))
    except requests.RequestException as e:
        return jsonify(error=f'Music search failed: {e}'),502

@app.get('/api/local')
def local():
    out=[]
    for p in sorted(MUSIC_DIR.iterdir()):
        if p.is_file() and p.suffix.lower() in ALLOWED:
            out.append({'id':'local:'+p.name,'title':p.stem,'artist':'Local Library','album':'GentleBeats','artwork':'','previewUrl':'/api/stream/'+p.name,'source':'Local file','local':True,'filename':p.name})
    return jsonify(results=out,count=len(out))

@app.get('/api/stream/<path:filename>')
def stream(filename):
    safe=secure_filename(filename)
    p=MUSIC_DIR/safe
    if not safe or not p.exists() or not p.is_file(): return jsonify(error='File not found'),404
    return send_from_directory(MUSIC_DIR,safe,conditional=True)

@app.post('/api/upload')
def upload():
    f=request.files.get('file')
    if not f or not f.filename: return jsonify(error='No audio file supplied'),400
    name=secure_filename(f.filename); ext=Path(name).suffix.lower()
    if ext not in ALLOWED: return jsonify(error='Use MP3, WAV, OGG, M4A, AAC or FLAC'),400
    f.save(MUSIC_DIR/name)
    return jsonify(ok=True,message=f'{name} added to your local library.')

@app.get('/api/lyrics/<path:filename>')
def lyrics(filename):
    safe=secure_filename(filename); stem=Path(safe).stem
    for ext in ('.txt','.lrc'):
        p=LYRICS_DIR/(stem+ext)
        if p.exists(): return jsonify(lyrics=p.read_text(encoding='utf-8'),source='Local licensed/user-supplied lyrics')
    return jsonify(lyrics='No local lyrics file was found for this song.',source='')

@app.get('/health')
def health(): return jsonify(status='ok')

if __name__ == '__main__': app.run(host='127.0.0.1',port=5000,debug=True)
