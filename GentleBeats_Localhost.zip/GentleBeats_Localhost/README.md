# GentleBeats — localhost

1. Open PowerShell in this folder.
2. Run `python -m venv .venv`
3. Run `.venv\Scripts\activate`
4. Run `pip install -r requirements.txt`
5. Run `python app.py`
6. Open **http://localhost:5000**

Features: real online song search and provider previews, working player controls, favorites, local audio upload/streaming, local lyrics files, and a Flask API.

Full-length local playback is for music you own or are licensed to use. Online commercial tracks use provider previews rather than ripping/downloading full tracks.
